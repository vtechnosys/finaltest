<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="ubcss/css/style.css">
</head>

<body>

    <!-- Top Header Area Starts -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="top-header-left">
                        <ul>
                            <li><a href="#."><i class="far fa-envelope"></i>info@unitingbharat.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="top-header-right text-right">
                        <ul>
                            <li>
                                <a href="#."><i class="fas fa-mobile-alt"></i>Help Line No :- +91 7083109554</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Header Area Ends -->

    <!-- Navigation Area Starts -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="ubcss/images/UBlogo.png" alt="" class="logo">
                <h2>Uniting Bharat
                </h2>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compensation.php">Refar & Earn</a>
                    </li>
					 <li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
					<li class="app">
                    <a href='https://play.google.com/store/apps/details?id=com.blondera.unitingbharat&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/ width="150px" height="100px"></a>   
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navigation Area Ends -->

    <!-- Breadcrumbs Area Starts -->
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-content text-left innerhead">
                        <h1>Terms & Conditions</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area Ends -->

    <!-- About Us Area Starts -->
    <div class="about-area">
        <div class="container">
            <div class="row">
                <!-- <div class="col-md-4">
                    <img src="images/about.png" alt="" class="about">
                </div> -->
                <div class="col-md-12">
                    <div class="about-content">
                        <!-- <h4>Unite As One Grow As One</h4> -->
                        <div class="about-text text-justify">
                            <figure>
                                <p id="aboutP">
                                   Welcome to www.blonderadigitalservicespvtltd.com. This website is owned and operated by BLOND ERA DIGITAL SERVICES PVT LTD & 35/18/2,New Paccha Peta,SOLAPUR,Maharashtra,413005. By visiting our website and accessing the information, resources, services, products, and tools we provide, you understand and agree to accept and adhere to the following terms and conditions as stated in this policy (hereinafter referred to as the Agreementâ), along with the terms and conditions as stated in our Privacy Policy (please refer to the Privacy Policy section below for more information).
                     We reserve the right to change this Agreement from time to time with/without notice. You acknowledge and agree that it is your responsibility to review this Agreement periodically to familiarize yourself with any modifications. Your continued use of this site after such modifications will constitute acknowledgment and agreement of the modified terms and conditions.<br><br>
                     PLEASE READ THIS TERMS OF SERVICE AGREEMENT CAREFULLY. BY USING THIS WEBSITE OR ORDERING PRODUCTS FROM THIS WEBSITE YOU AGREE TO BE BOUND BY ALL OF THE TERMS AND CONDITIONS OF THIS AGREEMENT.
                     <br><br>
                     This Agreement governs your use of this website www.blonderadigitalservicespvtltd.com (hereinafter referred to as the (Website), This Agreement includes and incorporates by this reference, the policies and guidelines referred below. BLOND ERA DIGITAL SERVICES PVT LTD reserves the right to change or revise the terms and conditions of this Agreement at any time by posting any changes or a revised Agreement on this Website. BLOND ERA DIGITAL SERVICES PVT LTD will/will not alert you that changes or revisions have been made by indicating on the top of this Agreement the date it was last revised. The changed or revised Agreement will be effective immediately after it is posted on this Website. Your use of the Website following the posting of any such changes or of a revised Agreement will constitute your acceptance of any such changes or revisions. BLOND ERA DIGITAL SERVICES PVT LTD encourages you to review this Agreement whenever you visit the Website to make sure that you understand the terms and conditions governing use of the Website. This Agreement does not alter in any way the terms or conditions of any other written agreement you may have with BLOND ERA DIGITAL SERVICES PVT LTD for other products or services. If you do not agree to this Agreement (including any referenced policies or guidelines), please immediately terminate your use of the Website.
                     <br><br>	
                     Responsible Use And Conduct
                     •	In order to access our Resources/ , you may be required to provide certain information about yourself (such as identification, email, phone number, contact details, etc.) as part of the registration process, or as part of your ability to use the Resources. You agree that any information you provide will always be accurate, correct, and up to date.
                     <br><br>
                     •	You are responsible for maintaining the confidentiality of any login information associated with any account you use to access our Resources/ . Accordingly, you are responsible for all activities that occur under your accounts.
                     •	Accessing (or attempting to access) any of our Resources/ by any means other than through the means we provide, is strictly prohibited. You specifically agree not to access (or attempt to access) any of our Resources/ through any automated, unethical or unconventional means.
                     <br><br>
                     •	Engaging in any activity that disrupts or interferes with our Resources/ , including the servers and/or networks to which our Resources / are located or connected, is strictly prohibited.
                     <br><br>
                     •	Attempting to copy, duplicate, reproduce, sell, trade, or resell our Resources / is strictly prohibited.
                     <br><br>
                     •	You are solely responsible for any consequences, losses, or damages that we may directly or indirectly incur or suffer due to any unauthorized activities conducted by you, as explained above, and may incur criminal or civil liability.
                     <br><br>
                     Privacy:
                     
                     BLOND ERA DIGITAL SERVICES PVT LTD believes strongly in protecting user privacy, which is why a separate Privacy Policy have been created in order to explain in detail how we collect, manage, process, secure, and store your private information. Please refer to BLOND ERA DIGITAL SERVICES PVT LTD privacy policy, incorporated by reference herein, that is posted on the Website.
                     Customer Solicitation:
                     <br><br>
                     Unless you notify our third party call center representatives or direct BLOND ERA DIGITAL SERVICES PVT LTD sales representatives, while they are calling you, of your desire to opt out from further direct company communications and solicitations, you are agreeing to continue to receive further emails and call solicitations from BLOND ERA DIGITAL SERVICES PVT LTD and its designated in house or third party call team(s).
                     Opt Out Procedure:
                     <br><br>
                     We provide 3 easy ways to opt out of from future solicitations -<br><br>
                     1.	You may use the opt out link found in any email solicitation that you may receive.<br><br>
                     2.	You may also choose to opt out, via sending your email address to: [opt-out email].<br><br>
                     3.	You may send a written remove request to BLOND ERA DIGITAL SERVICES PVT LTD sales representatives, while they are calling you, of your desire to opt out from further direct company communications and solicitations, you are agreeing to continue to receive further emails and call solicitations from BLOND ERA DIGITAL SERVICES PVT LTD & ADDRESS 35/18/2,New Paccha Peta,SOLAPUR,Maharashtra,413005.
                     <br><br>
                     Proprietary Rights:
                     
                     BLOND ERA DIGITAL SERVICES PVT LTD has proprietary rights . BLOND ERA DIGITAL SERVICES PVT LTD also has rights to all trademarks and trade dress and specific layouts of this webpage, including calls to action, text placement, images and other information.
                     <br><br>
                     
                     Content, Intellectual Property, Third Party Links:
                     
                     This Website also offers information, both directly and through indirect links to third-party websites, about (kind of information). BLOND ERA DIGITAL SERVICES PVT LTD does not always create the information offered on this Website; instead the information is often gathered from other sources. To the extent that BLOND ERA DIGITAL SERVICES PVT LTD does create the content on this Website, such content is protected by intellectual property laws of the India, foreign nations, and international bodies. Unauthorized use of the material may violate copyright, trademark, and/or other laws. You acknowledge that your use of the content on this Website is for personal, non-commercial use. Any links to third-party websites are provided solely as a convenience to you. BLOND ERA DIGITAL SERVICES PVT LTD does not endorse the contents on any such third-party websites. BLOND ERA DIGITAL SERVICES PVT LTD is not responsible for the content of or any damage that may result from your access to or reliance on these third-party websites. If you link to third-party websites, you do so at your own risk.
                     <br><br>
                     Use of Website:
                     
                     BLOND ERA DIGITAL SERVICES PVT LTD is not responsible for any damages resulting from use of this website by anyone. You will not use the Website for illegal purposes. You will -<br><br>
                     •	abide by all applicable local, state, national, and international laws and regulations in your use of the Website (including laws regarding intellectual property),<br><br>
                     •	not interfere with or disrupt the use and enjoyment of the Website by other users,<br><br>
                     •	not resell material on the Website,<br><br>
                     •	not engage, directly or indirectly, in transmission of "spam", chain letters, junk mail or any other type of unsolicited communication, and<br><br>
                     •	not defame, harass, abuse, or disrupt other users of the Website.
                     <br><br>
                     License:
                     
                     By using this Website, you are granted a limited, non-exclusive, non-transferable right to use the content and materials on the Website in connection with your normal, non-commercial use of the Website. You may not copy, reproduce, transmit, distribute, or create derivative works of such content or information without express written authorization from BLOND ERA DIGITAL SERVICES PVT LTD or the applicable third party (if third party content is at issue).
                     Blogs:<br><br>
                     •	We may provide various open communication tools on our website, such as blog comments, blog posts, public chat, forums, message boards, newsgroups, product ratings and reviews, various social media services, etc. You understand that generally we do not pre-screen or monitor the content posted by users of these various communication tools, which means that if you choose to use these tools to submit any type of content to our website, then it is your personal responsibility to use these tools in a responsible and ethical manner. By posting information or otherwise using any open communication tools as mentioned, you agree that you will not upload, post, share, or otherwise distribute any content that:<br><br>
                     o	is illegal, threatening, defamatory, abusive, harassing, degrading, intimidating, fraudulent, deceptive, invasive, racist, or contains any type of suggestive, inappropriate, or explicit language;<br><br>
                     o	infringes on any trademark, patent, trade secret, copyright, or other proprietary right of any party;<br><br>
                     o	contains any type of unauthorized or unsolicited advertising;<br><br>
                     o	impersonates any person or entity, including any www.blonderadigitalservicespvtltd.com/BLOND ERA DIGITAL SERVICES PVT LTD employees or representatives.
                     <br><br>
                     •	We have the right at our sole discretion to remove any content that, we feel in our judgment does not comply with this User Agreement, along with any content that we feel is otherwise offensive, harmful, objectionable, inaccurate, or violates any 3rd party copyrights or trademarks. We are not responsible for any delay or failure in removing such content. If you post content that we choose to remove, you hereby consent to such removal, and consent to waive any claim against us.<br><br>
                     •	We do not assume any liability for any content posted by you or any other 3rd party users of our website. However, any content posted by you using any open communication tools on our website, provided that it doesn't violate or infringe on any 3rd party copyrights or trademarks, becomes the property of BLOND ERA DIGITAL SERVICES PVT LTD, and as such, gives us a perpetual, irrevocable, worldwide, royalty-free, exclusive license to reproduce, modify, adapt, translate, publish, publicly display and/or distribute as we see fit. This only refers and applies to content posted via open communication tools as described, and does not refer to information that is provided as part of the registration process, necessary in order to use our Resources. All information provided as part of our registration process is covered by our Privacy Policy.<br><br>
                     •	You agree to indemnify and hold harmless www.blonderadigitalservicespvtltd.com a digital property of BLOND ERA DIGITAL SERVICES PVT LTD and its parent company and affiliates, and their directors, officers, managers, employees, donors, agents, and licensors, from and against all losses, expenses, damages and costs, including reasonable attorneys' fees, resulting from any violation of this User Agreement or the failure to fulfill any obligations relating to your account incurred by you or any other person using your account. We reserve the right to take over the exclusive defense of any claim for which we are entitled to indemnification under this User Agreement. In such event, you shall provide us with such cooperation as is reasonably requested by us.
                     <br><br>
                     Posting:
                     
                     By posting, storing, or transmitting any content on the Website, you hereby grant BLOND ERA DIGITAL SERVICES PVT LTD a perpetual, worldwide, non-exclusive, royalty-free, assignable, right and license to use, copy, display, perform, create derivative works from, distribute, have distributed, transmit and assign such content in any form, in all media now known or hereinafter created, anywhere in the world. BLOND ERA DIGITAL SERVICES PVT LTD does not have the ability to control the nature of the user-generated content offered through the Website. You are solely responsible for your interactions with other users of the Website and any content you post. BLOND ERA DIGITAL SERVICES PVT LTD is not liable for any damage or harm resulting from any posts by or interactions between users. BLOND ERA DIGITAL SERVICES PVT LTD reserves the right, but has no obligation, to monitor interactions between and among users of the Website and to remove any content BLOND ERA DIGITAL SERVICES PVT LTD deems objectionable, in BLOND ERA DIGITAL SERVICES PVT LTD's sole discretion.
                     <br><br>
                     Disclaimer of Warranties:
                     
                     Your use of this website and/or are at your sole risk. The website and are offered on an "as is" and "as available" basis. BLOND ERA DIGITAL SERVICES PVT LTD expressly disclaims all warranties of any kind, whether express or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose and non-infringement with respect to the or website content, or any reliance upon or use of the website content or 
                     Without limiting the generality of the foregoing, BLOND ERA DIGITAL SERVICES PVT LTD makes no warranty:
                     <br><br>
                     •	that the information provided on this website is accurate, reliable, complete, or timely.<br><br>
                     •	that the links to third-party websites are to information that is accurate, reliable, complete, or timely.<br><br>
                     •	no advice or information, whether oral or written, obtained by you from this website will create any warranty not expressly stated herein
                     Some jurisdictions do not allow the exclusion of certain warranties, so some of the above exclusions may not apply to you.
                     Limitation Of Liability
                     <br><br>
                     BLOND ERA DIGITAL SERVICES PVT LTD entire liability, and your exclusive remedy, in law, in equity, or otherwise, with respect to the website content / and/or for any breach of this agreement is solely limited to the amount you paid
                     BLOND ERA DIGITAL SERVICES PVT LTD will not be liable for any direct, indirect, incidental, special or consequential damages in connection with this agreement &/or in any manner, including liabilities resulting from:
                     <br>
                     •	the use or the inability to use the website content / ;<br><br>
                     •	the cost of procuring substitute content / ;<br><br>
                     •	any information obtained / purchased or transactions entered into through the website; or
                     •	any lost profits you allege.<br><br>
                     Some jurisdictions do not allow the limitation or exclusion of liability for incidental or consequential damages so some of the above limitations may not apply to you.
                     conjunction with the Limitation of Liability as explained above, you expressly understand and agree that any claim against us shall be limited to the amount you paid, if any, for use of . www.blonderadigitalservicespvtltd.com/BLOND ERA DIGITAL SERVICES PVT LTD will not be liable for any direct, indirect, incidental, consequential or exemplary loss or damages which may be incurred by you as a result of using our Resources / , or as a result of any changes, data loss or corruption, cancellation, loss of access, or downtime to the full extent that applicable limitation of liability laws apply.
                     <br><br>
                     Indemnification:
                     
                     You will release, indemnify, defend and hold harmless BLOND ERA DIGITAL SERVICES PVT LTD, and any of its contractors, agents, employees, officers, directors, shareholders, affiliates and assigns from all liabilities, claims, damages, costs and expenses, including reasonable attorneys' fees and expenses, of third parties relating to or arising out of
                     •	this Agreement or the breach of your warranties, representations and obligations under this Agreement;<br><br>
                     •	the Website content or your use of the Website content;<br><br>
                     •	any intellectual property or other proprietary right of any person or entity;<br><br>
                     •	your violation of any provision of this Agreement; or<br><br>
                     •	any information or data you supplied to BLOND ERA DIGITAL SERVICES PVT LTD.<br><br>
                     When BLOND ERA DIGITAL SERVICES PVT LTD is threatened with suit or sued by a third party, BLOND ERA DIGITAL SERVICES PVT LTD may seek written assurances from you concerning your promise to indemnify BLOND ERA DIGITAL SERVICES PVT LTD; your failure to provide such assurances may be considered by BLOND ERA DIGITAL SERVICES PVT LTD to be a material breach of this Agreement. BLOND ERA DIGITAL SERVICES PVT LTD will have the right to participate in any defense by you of a third-party claim related to your use of any of the Website content / , with the counsel of BLOND ERA DIGITAL SERVICES PVT LTDâ€™s choice at its expense. BLOND ERA DIGITAL SERVICES PVT LTD will reasonably cooperate in any defense by you of a third-party claim at your request and expense. You will have sole responsibility to defend BLOND ERA DIGITAL SERVICES PVT LTD against any claim, but you must receive BLOND ERA DIGITAL SERVICES PVT LTDâ€™s prior written consent regarding any related settlement. The terms of this provision will survive any termination or cancellation of this Agreement or your use of the Website / .
                     Copyrights / Trademarks
                     <br><br>
                     All content and materials available on www.blonderadigitalservicespvtltd.com, including but not limited to text, graphics, website name, code, images and logos are the intellectual property of BLOND ERA DIGITAL SERVICES PVT LTD and are protected by applicable copyright and trademark law. Any inappropriate use, including but not limited to the reproduction, distribution, display or transmission of any content on this site is strictly prohibited, unless specifically authorized by BLOND ERA DIGITAL SERVICES PVT LTD.
                     Agreement To Be Bound
                     <br><br>
                     BY USING THIS WEBSITE OR ORDERING , YOU ACKNOWLEDGE THAT YOU HAVE READ AND AGREE TO BE BOUND BY THIS AGREEMENT AND ALL TERMS AND CONDITIONS ON THIS WEBSITE.
                     General Clause:
                     •	Force Majeure: BLOND ERA DIGITAL SERVICES PVT LTD will not be deemed in default hereunder or held responsible for any cessation, interruption or delay in the performance of its obligations hereunder due to earthquake, flood, fire, storm, natural disaster, act of God, war, terrorism, armed conflict, labor strike, lockout, or boycott.<br><br>
                     •	Cessation of Operation: BLOND ERA DIGITAL SERVICES PVT LTD may at any time, in its sole discretion and without advance notice to you, cease operation of the Website <br><br>
                     •	Entire Agreement: This Agreement comprises the entire agreement between you and BLOND ERA DIGITAL SERVICES PVT LTD and supersedes any prior agreements pertaining to the subject matter contained herein.
                     <br><br>
                     Governing Law:
                     
                     This website is controlled by BLOND ERA DIGITAL SERVICES PVT LTD from our offices located in the state of Maharashtra, India. It can be accessed by most countries around the world. As each country has laws that may differ from those of Maharashtra, India, by accessing our website, you agree that the statutes and laws of Maharashtra, India, without regard to its conflict of law principles to the contrary and the United Nations Convention on the International Sales of Goods, will apply to all matters relating to the use of this website 
                     Effect of Waiver:
                     <br><br>
                     The failure of BLOND ERA DIGITAL SERVICES PVT LTD to exercise or enforce any right or provision of this Agreement will not constitute a waiver of such right or provision. If any provision of this Agreement is found by a court of competent jurisdiction to be invalid, the parties nevertheless agree that the court should endeavor to give effect to the parties' intentions as reflected in the provision and the other provisions of this Agreement remain in full force and effect.
                     <br><br>
                     Governing Law/Jurisdiction:
                     
                     This Website originates from the SOLAPUR, Maharashtra, India. This Agreement will be governed by the laws of the State of Maharashtra, India. It can be accessed by most countries around the world. As each country has laws that may differ from those of Maharashtra, India without regard to its conflict of law principles to the contrary. Neither you nor BLOND ERA DIGITAL SERVICES PVT LTD will commenceMaharashtra), India. This Agreement will be governed by the laws of the State of Maharashtra, India. It can be accessed by most countries around the world. As each country has laws that may differ from those of Maharashtra, India without regard to its conflict of law principles to the contrary. Neither you nor or prosecute any suit, proceeding or claim to enforce the provisions of this Agreement, to recover damages for breach of or default of this Agreement, or otherwise arising under or by reason of this Agreement, other than in courts located in State of Maharashtra, India. It can be accessed by most countries around the world. As each country has laws that may differ from those of Maharashtra, India. By using this Website or ordering , you consent to the jurisdiction and venue of such courts in connection with any action, suit, proceeding or claim arising under or by reason of this Agreement. You hereby waive any right to trial by jury arising out of this Agreement and any related documents.
                     This website is controlled by BLOND ERA DIGITAL SERVICES PVT LTD from our offices located in the state of Maharashtra, India. It can be accessed by most countries around the world. As each country has laws that may differ from those of Maharashtra, India, by accessing our website, you agree that the statutes and laws of Maharashtra, India without regard to the conflict of laws and the United Nations Convention on the International Sales of Goods, will apply to all matters relating to the use of this website 
                     Furthermore, any action to enforce this User Agreement shall be brought in the courts having jurisdiction over such issue, located in Maharashtra, India. You hereby agree to judgement passed by such courts and waive any right to jurisdictional, venue, or inconvenient forum objections to such courts.
                     <br><br>
                     Statute of Limitation:
                     
                     You agree that regardless of any statute or law to the contrary, any claim or cause of action arising out of or related to use of the Website or or this Agreement must be filed within one (1) year after such claim or cause of action arose else be forever barred.
                     Waiver of Class Action Rights:
                     <br><br>
                     BY ENTERING INTO THIS AGREEMENT, YOU HEREBY IRREVOCABLY WAIVE ANY RIGHT YOU MAY HAVE TO JOIN CLAIM WITH THOSE OF OTHERS IN THE FORM OF A CLASS ACTION OR SIMILAR PROCEDURAL DEVICE. ANY CLAIMS ARISING OUT OF OR RELATING TO OR IN CONNECTION WITH THIS AGREEMENT MUST BE ASSERTED INDIVIDUALLY.
                     <br><br>
                     Termination:
                     
                     BLOND ERA DIGITAL SERVICES PVT LTD reserves the right to terminate your access to the Website if it reasonably believes, in its sole discretion, that you have breached any of the terms and conditions of this Agreement. Following termination, you will not be permitted to use the Website If your access to the Website is terminated, BLOND ERA DIGITAL SERVICES PVT LTD reserves the right to exercise whatever means it deems necessary to prevent unauthorized access of the Website. This Agreement will survive indefinitely unless and until BLOND ERA DIGITAL SERVICES PVT LTD chooses, in its sole discretion and without advance notice to you, to terminate it.
                     <br><br>
                     Domestic Use:
                     
                     BLOND ERA DIGITAL SERVICES PVT LTD makes no representation that the Website or are appropriate or available for use in locations outside India. Users who access the Website from outside India do so at their own risk and initiative and must bear all responsibility for compliance with any applicable local laws.
                     Guarantee:
                     
                     Unless otherwise expressed, BLOND ERA DIGITAL SERVICES PVT LTD & www.blonderadigitalservicespvtltd.com expressly disclaims all warranties and conditions of any kind, whether express or implied, including, but not limited to the implied warranties and conditions of merchantability, fitness of content / for a particular purpose and non-infringement.
                     <br><br>
                     Assignment:
                     
                     You may not assign your rights and obligations under this Agreement to anyone. BLOND ERA DIGITAL SERVICES PVT LTD may assign its rights and obligations under this Agreement in its sole discretion and without advance notice to you.
                     BY USING THIS WEBSITE OR ORDERING FROM THIS WEBSITE YOU AGREE TO BE BOUND BY ALL OF THE TERMS AND CONDITIONS OF THIS AGREEMENT.
                     <br><br>
                     Contact Information:<br>
                     
                     If you have any questions or comments about these our Terms of Service as outlined above, you can contact us at:<br>
                     BLOND ERA DIGITAL SERVICES PVT LTD<br>
                     35/18/2, New Paccha Peta,<br>
                     SOLAPUR.<br>
                     MAHARASHTRA. INDIA.  -  413005
                     <br>
                     Helpline: +91 7083109554<br>
                     Email: info@blonderadigitalservicespvtltd.com
                          </p>
                    </figure>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us Area Ends -->

    <!-- Footer Area Starts -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="term_conditions.php">
                        <h6>Terms and Condition*
                        </h6>
                    </a>
                </div>
                <div class="col-md-7">
                    <h6>Copyright © 2022, All rights reserved | Design & Developed by <a href="https://www.vertextechnosys.com/"> Vertex Technosys</a></h6>
                </div>
                <div class="col-md-2">
                    <a href="privacy_policy.php">
                        <h6>Privacy Policy</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Area Ends -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>