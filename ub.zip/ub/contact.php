<?php
   
    
if(isset($_POST['btn']))
{
	 $conn = mysqli_connect("localhost", "root", "", "unitingbharat_DB");
    $cname=$_POST['name'];
	$email=$_POST['email'];
	$sub=$_POST['subject'];
	$msg=$_POST['message'];
	if($email!=null && $sub!=null && $msg!=null && $cname!=null)
	{
	$sql="INSERT INTO `contact`(`cname`,`email`, `subject`, `message`) VALUES ('$cname','$email','$sub','$msg')";
			if(mysqli_query($conn,$sql))
			{
				echo '<script>alert("Email : '.$email.' we will contact you soon...!!!");</script>';
			}
			else
			{
				echo "error".mysqli_error($conn);
			}
	}
	else
	{
		echo '<script>alert("Enter all fields...!");</script>';
	}
	
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="ubcss/css/style.css">
</head>

<body>

    <!-- Top Header Area Starts -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="top-header-left">
                        <ul>
                            <li><a href="#."><i class="far fa-envelope"></i>info@unitingbharat.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="top-header-right text-right">
                        <ul>
                            <li>
                                <a href="#."><i class="fas fa-mobile-alt"></i>Help Line No :- +91 7083109554</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Header Area Ends -->

    <!-- Navigation Area Starts -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="ubcss/images/UBlogo.png" alt="" class="logo">
                <h2>Uniting Bharat
                </h2>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compensation.php">Refar & Earn</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
					<li class="app">
                    <a href='https://play.google.com/store/apps/details?id=com.blondera.unitingbharat&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/ width="150px" height="100px"></a>   
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navigation Area Ends -->

    <!-- Breadcrumbs Area Starts -->
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-content text-left innerhead">
                        <h1>Contact Us</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area Ends -->

    <!-- Contact Area Starts -->
    <div class="contact-area py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="col-md-12">
                        <div class="form-text">
                            <p style="color:black"><b>info@unitingbharat.com
                            </b></p>
                        </div>
                    </div>
                    <form action="" method="post" class="contact-form">
                        <div class="col-md-12">
                            <input type="text" id="name" name="name" class="input-text" placeholder="Your Name" required>
                        </div>
                        <div class="col-md-12">
                            <input type="email" id="email" name="email" class="input-text" placeholder="Your Email" required>
                        </div>
                        <div class="col-md-12">
                            <input type="text" id="subject" name="subject" class="input-text" placeholder="Subject" required>
                        </div>
                        <div class="col-md-12">
                            <textarea placeholder="Message" cols="30" rows="3" required="" name="message"></textarea>
                        </div>
                        <div class="col-md-12">
                            <div class="readmore">
                                <input type="submit" name="btn" class="btn-read" value="Send Message">
                            </div>
                        </div>
                    </form>
                </div>
                 <div class="col-md-6" style="
    padding-top: 32px;">
                    <h2 class="contact-text"> UNITING BHARAT</h2>
                    <div class="single-contact">
                        <i class="far fa-mobile"></i>
                        <h5>Mobile</h5>
                        <p>Help Line No :- +91 7083109554</p>
                    </div>
                    <div class="single-contact">
                        <i class="far fa-envelope"></i>
                        <h5>Email</h5>
                        <p>info@unitingbharat.com</p>
                    </div>
                    <div class="single-contact">
                        <!--<i class="far fa-envelope"></i>-->
                        <!--<h5>Email</h5>-->
                        <!--<p>info@unitingbharat.com</p>-->
                        <!--<p>info@blonderadigitalservicesptvltd.com</p>-->
                    </div>
                    </div>
                    <!--<div
                    class="single-contact">-->
                    <!--    <h5>Grievance Cell</h5>-->
                        <!-- <p>35/18/2, NEW PACCHA PETH, SOLAPUR, MAHARASHTRA, INDIA. 413005</p> -->
                    <!--    <div class="inner-text">-->
                    <!--        <div><b>Name :</b><p>Ramesh Adam</p></div>-->
                    <!--        <div><b>Contact :</b><p>+91 9999999999</p></div>-->
                    <!--        <div><b>Email :</b><p>VertexTechnosys@gmail.com</p></div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
            </div>
        </div>
    </div>
    <!-- Contact Area Ends -->

    <!-- Footer Area Starts -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="term_conditions.php">
                        <h6>Terms and Condition*
                        </h6>
                    </a>
                </div>
                <div class="col-md-7">
                    <h6>Copyright © 2021, All rights reserved | Design & Developed by <a href="https://www.vertextechnosys.com/"> Vertex Technosys</a></h6>
                </div>
                <div class="col-md-2">
                    <a href="privacy_policy.php">
                        <h6>Privacy Policy</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Area Ends -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>