<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="ubcss/css/style.css">
</head>

<body>

    <!-- Top Header Area Starts -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="top-header-left">
                        <ul>
                            <li><a href="#."><i class="far fa-envelope"></i>info@unitingbharat.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="top-header-right text-right">
                        <ul>
                            <li>
                                <a href="#."><i class="fas fa-mobile-alt"></i>Help Line No :- +91 7083109554</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Header Area Ends -->

    <!-- Navigation Area Starts -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="ubcss/images/UBlogo.png" alt="" class="logo">
                <h2>Uniting Bharat
                </h2>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compensation.php">Refar & Earn</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
					<li class="app">
                    <a href='https://play.google.com/store/apps/details?id=com.blondera.unitingbharat&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/ width="150px" height="100px"></a>   
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navigation Area Ends -->

    <!-- Breadcrumbs Area Starts -->
    <div class="page-title">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-content text-left innerhead">
                        <h1>About Us</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Breadcrumbs Area Ends -->

    <!-- About Us Area Starts -->
    <div class="about-area">
        <div class="container">
            <div class="row">
                <!-- <div class="col-md-4">
                    <img src="images/about.png" alt="" class="about">
                </div> -->
                <div class="col-md-12">
                    <div class="about-content">
                        <center><h4>Unite As One Grow As One</h4></center>
                        <div class="about-text text-justify">
                        
						<p align="justify">UNITING BHARAT is a Digital Service APP Programmed on Refer & Earn concept it is designed & developed by, 
						BLOND ERA  DIGITAL SERVICES PVT. LTD. </p>
						<p align="justify">It is a B2C referal base business to customers it means a customer can directly use multiple services of APP with the help of his online UPI banking. B2C is a fastest growing online sector which gives space to entrepreneurs for experimenting new ideas and providing new services to the customers through the secure UPI payment method. We offer a wide spectrum of services to suit every need and requirement of our clients. </p>
						<p align="justify">UNITING BHARAT provieds Cash Back on every Single services used on this APP for its Clients.</p>
						<ul style="list-style-type:square;margin-left:15px;"><li>Recharges :-  of Prepaid Mobile, DTH, FasTag, Cable,</li> 
<li>Bill Payment :-  of Postpaid Mobile, Broadband, Landline, Electricity,</li>  
<li>Utility Payments :- of Gas Cylinder, Piped Gas, Water, Corporation Tax,</li>
<li>Financial Services :- of Loan Emi, Insurancce Premium, e-Challan </li>
<li>Online Bookings :-  of Bus, Train, Flight, Cab, Movies, Hotels & Metro Trains, </li>
<li>Scan & Pay :- All QR Scan & Pay Option. ( Cash Back on every singel Payment ) </li>
</ul></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us Area Ends -->

    <!-- Footer Area Starts -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="term_conditions.php">
                        <h6>Terms and Condition*
                        </h6>
                    </a>
                </div>
                <div class="col-md-7">
                    <h6>Copyright © 2022, All rights reserved | Design & Developed by <a href="https://www.vertextechnosys.com/"> Vertex Technosys</a></h6>
                </div>
                <div class="col-md-2">
                    <a href="privacy_policy.php">
                        <h6>Privacy Policy</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Area Ends -->

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

</body>

</html>