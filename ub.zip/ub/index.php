<?php
   $conn = mysqli_connect("localhost", "root", "", "unitingbharat_DB");
    
if(isset($_POST['btn']))
{
	// $conn = mysqli_connect("localhost", "unitingbharat_user", "HUM063it404@", "unitingbharat_DB");
    $cname=$_POST['name'];
	$email=$_POST['email'];
	$sub=$_POST['subject'];
	$msg=$_POST['message'];
	if($email!=null && $sub!=null && $msg!=null && $cname!=null)
	{
	$sql="INSERT INTO `contact`(`cname`,`email`, `subject`, `message`) VALUES ('$cname','$email','$sub','$msg')";
			if(mysqli_query($conn,$sql))
			{
				echo '<script>alert("Email : '.$email.' we will contact you soon...!!!");</script>';
			}
			else
			{
				echo "error".mysqli_error($conn);
			}
	}
	else
	{
		echo '<script>alert("Enter all fields...!");</script>';
	}
	
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Unite As One Grow As One">
    <!--<meta property="og:image" itemprop="image" content="images/UBlogo.png">-->
    <meta property="og:title" content="Uniting Bharat" />
    <meta property="og:url" content="https://www.unitingbharat.com" />
    <meta property="og:description" content="Uniting Bharat Unite As One Grow As One">
    <meta property="og:image" content="https://unitingbharat.com/images/UBlogo_tyny.png">
    <link itemprop="thumbnailUrl" href="https://unitingbharat.com/images/UBlogo_tyny.png"> 
    <meta property="og:type" content="website" />
    <!-- CSS -->
    <link rel="shortcut icon" type="image/x-icon" href="https://unitingbharat.com/images/UBlogo_tyny.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="ubcss/css/style.css">
</head>

<body>

    <!-- Top Header Area Starts -->
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="top-header-left">
                        <ul>
                            <li><a href="#."><i class="far fa-envelope"></i>info@unitingbharat.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="top-header-right text-right">
                        <ul>
                            <li>
                                <a href="#."><i class="fas fa-mobile-alt"></i>Help Line No :- +91 7083109554</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Top Header Area Ends -->

    <!-- Navigation Area Starts -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="ubcss/images/UBlogo.png" alt="" class="logo">
                <h2>Uniting Bharat
                </h2>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="compensation.php">Refar & Earn</a>
                    </li>
					<li class="nav-item">
                        <a class="nav-link" href="service.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact Us</a>
                    </li>
                    <li class="app">
                    <a href='https://play.google.com/store/apps/details?id=com.blondera.unitingbharat&pcampaignid=pcampaignidMKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/static/images/badges/en_badge_web_generic.png'/ width="150px" height="100px"></a>   
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Navigation Area Ends -->

    <!-- Slider Area Starts -->
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <div class="swiper-slide"><img src="ubcss/images/banner.jpg" alt=""></div>
            <div class="swiper-slide"><img src="ubcss/images/banner-2.jpg" alt=""></div>
            <div class="swiper-slide"><img src="ubcss/images/banner-3.jpg" alt=""></div>
            <div class="swiper-slide"><img src="ubcss/images/banner-4.jpg" alt=""></div>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
    </div>
    <!-- Slider Area Ends -->

    <!-- About Us Area Starts -->
    <div class="about-area py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="ubcss/images/about.png" alt="" class="about">
                </div>
                <div class="col-md-8">
                    <div class="about-content">
                        <h2>WELCOME TO</h2>
                        <h3>Uniting Bharat</h3>
                        <p align="justify"><b>UNITING BHARAT</b> is a Digital Service App Programmed on Refer & Earn concept it is designed & developed by <b>BLOND ERA DIGITAL SERVICES PVT.LTD.</b><br>Uniting Bharat provides excellent Incentives to any person who is willing to put efforts & refer people to promote the company sales & services.<br>To be a part of Uniting Bharat just Downlode the App <b>UNITING BHARAT</b> from <b>Google Play Store </b> & register online to join our family.</p>
                        <div class="readmore">
                            <a href="about.php" class="btn-read">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- About Us Area Ends -->

    <!-- Info Area Starts -->
    <div class="info-area mb-5">
        <div class="container">
            <div class="info-details">
                <div class="row">
                    <div class="col-md-9 m-auto">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="info-text text-center" style=" background-image: linear-gradient(-90deg, #67e767, white,#f1bd5c);">
                                    <h2><b>DONATION</b></h2>
                                    <div class="info-icon">
                                        <!--<i class="far fa-box-usd"></i>-->
                                        <img src="ubcss/images/WhatsApp Image 2022-01-18 at 16.26.15.jpeg" width="150px;" height="100px">
                                    </div><br>
                                    <h3>INDIAN ARMY :-  <?php 
            $sql = "select count(*) from tbl_bhim_pay where payee_id='NGO2'";
            //echo $sql;
            $rs = mysqli_query($conn,$sql);
            $rw = mysqli_fetch_row($rs);
            //echo mysqli_error($conn);
            echo ($rw[0]-118)*100;
          ?></h3>
                                    <font color="black">armedforcesflagdayfund@sbi<br></font>
                                        <a href="http://ksb.gov.in">http://ksb.gov.in</a>
                                    
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="info-text text-center" style=" background-image: linear-gradient(-90deg, #67e767, white,#f1bd5c);">
                                     <h2><b>DONATION</b></h2>
                                    <div class="info-icon">
                                        <!--<i class="far fa-box-usd"></i>-->
                                        <img src="ubcss/images/WhatsApp Image 2022-01-18 at 16.26.15.jpeg" width="150px;" height="100px">
                                    </div><br>
                                    <h3>NGO AKSHAYA PATRA :- <?php 
            $sql = "select count(*) from tbl_bhim_pay where payee_id='NGO2'";
            //echo $sql;
            $rs = mysqli_query($conn,$sql);
            $rw = mysqli_fetch_row($rs);
            //echo mysqli_error($conn);
            echo ($rw[0]-118)*100;
          ?></h3>
                                    <font color="black">Akshayapatra@kotak <br></font><a href="https://www.akshayapatra.org">https://www.akshayapatra.org</a>
                                    
									
                                </div>
                            </div>
                        </div>
						<div class="row">
                            <div class="col-md-12">
                                <div class="info-text text-center" style=" background-image: linear-gradient(-90deg, #67e767, white,#f1bd5c);">
                                    <h2><b>TESTIMONIAL</b></h2>
                                    <div class="info-icon">
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                    </div>
						<?php
                    // $con =mysqli_connect("localhost","root","","vertez");
                    $sql = "select * from testimonial";
                    $rs = mysqli_query($conn,$sql);?>
                    <marquee direction="up" height="200" scrolldelay=300>
                    <?php
                    while($rw = mysqli_fetch_row($rs))
                    {
                    ?>
                    
                    <div>Name: <b><?php echo $rw[1];?></b><br>
                    Message:<b><?php echo $rw[3];?></b></div><br>
                    
				    <?php
                    }
                    ?>
                    </marquee>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Info Area Ends -->

    <!-- Footer Area Starts -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <a href="term_conditions.php">
                        <h6>Terms and Condition*</h6>
                    </a>
                </div>
                <div class="col-md-7">
                    <h6>Copyright © 2022, All rights reserved | Design & Developed by <a href="https://www.vertextechnosys.com/"> Vertex Technosys</a></h6>
                </div>
                <div class="col-md-2">
                    <a href="privacy_policy.php">
                        <h6>Privacy Policy</h6>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Area Ends -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

    <script>
        var swiper = new Swiper(".mySwiper", {
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });
    </script>
</body>

</html>